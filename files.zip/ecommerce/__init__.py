print("Ecommerce Initialised")
